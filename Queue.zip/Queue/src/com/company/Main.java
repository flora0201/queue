package com.company;

import java.util.LinkedList;
import java.util.Queue;

public class Main {
    public static void main(String[] args) {
        Queue<Integer> numbers = new LinkedList<>();
        numbers.offer(1);
        numbers.offer(2);
        numbers.offer(3);
        numbers.offer(4);
        numbers.offer(5);
        System.out.println("Inserting a number: " + numbers);

        int removedNumber = numbers.poll();
        System.out.println("remove: " + removedNumber);

        System.out.println("Queue deletion: " + numbers);
        }
    }

